fruits = {"apple" , "banana" , "cherry"}
for fruit in fruits:
    print(fruit)

for number in range(5):
    print(number)

ages={"Alice":30, "bob":25, "charlie":35}
for (name,age) in (ages).items():
    print(f"{name} is {age} years old")

for i in range(3):
    print(i)
else:
    print("loop finished")


