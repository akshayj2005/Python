for i in range(2):
    for j  in range(3):
        print(f"i={i} , j={j}")
