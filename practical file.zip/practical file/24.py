fruits=["apple", "banana", "cherry"]
for index,fruit in enumerate(fruits):
    print(f"index {index} : {fruit}") 
