input_str = input("Enter integers separated by spaces: ")
for val in input_str.split():
    num = int(val)
    print(num)
print()