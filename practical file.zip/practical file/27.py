my_list = input("enter values seperated by spaces : ").split()
print(f"hello  these are list of inputs : {my_list}")

int_list = list(map(int, input("enter numbers seperated by spaces : ").split()))
print(f"the list of integers : {int_list}")


