item1 , item2 = input("enter two items seperated by a comma : ").split(',')
print(f"item 1 : {item1.strip()}")
print(f"item 2 : {item2.strip()}")




