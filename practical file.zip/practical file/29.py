num = int(input("Enter a number: "))

temp  = num %10
print("Last digit of the number is:",temp)