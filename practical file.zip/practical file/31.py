for num in range(10):
    if num%2==0: #check if the number is even
        continue  #skip the rest of the loop body for even numbers
    print(num)  #print only odd numbers
