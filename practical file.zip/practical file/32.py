num = 0
while num < 10:
    print(num)
    num += 1
    