s = "hello"
i = 0

while i < len(s):
    print(s[i])
    i += 1

