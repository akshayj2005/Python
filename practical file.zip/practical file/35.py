for num in range(10):
    if num==5:
        break
    print(num)
