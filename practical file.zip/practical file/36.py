count=0
while count<10:
    if count==5: #check if count is 5
        break #exit the loop when count is 5
    print(count) #print count less than 5
    count+=1
