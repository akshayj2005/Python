my_list=[1,2,3,4,5]
my_list.append(6)
my_list.insert(2,2.5)
my_list.remove(4)
print(my_list)
