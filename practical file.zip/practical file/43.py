my_list=['a','b','c','d','e']
first_element=my_list[0]
last_element=my_list[-1]
sub_list=my_list[1:4]
print("first element:", first_element)
print("last element:", last_element)
print("sliced list:", sub_list)
