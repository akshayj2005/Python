my_tuple=(1,2,3,4)
print(my_tuple[0])
print(my_tuple[-1])