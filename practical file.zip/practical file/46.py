nested_tuple=(1,(2,3),4)
print(nested_tuple[1][0])

