my_dict={'name':'Alice','age':25}
my_dict['age']=26
my_dict['city']='New York'
print(my_dict)
