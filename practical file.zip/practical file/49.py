my_dict={'name':'Bob','age':30,'job':'engineer'}
name= my_dict.get('name')
my_dict.pop('job')
print(name)
print(my_dict)
         
