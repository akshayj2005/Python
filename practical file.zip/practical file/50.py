my_dict={'a':1,'b':2,'c':3}
for key,value in my_dict.items():
    print(f"{key}:{value}")
