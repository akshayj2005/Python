my_list=[1,2,3,4]
it=iter(my_list)
print(next(it))
print(next(it))
