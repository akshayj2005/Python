my_list=[1,2,3,4]
it=iter(my_list)
for item in it:
    print(item)
