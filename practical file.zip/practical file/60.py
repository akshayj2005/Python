squares = {x**2 for x in range(5)}
print(squares)
