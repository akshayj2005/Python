global_var = "I am global"

def example_function():
    print(global_var) #Accessible

example_function()
print(global_var)

