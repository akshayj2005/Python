# Simple function demonstration
def greet():
    print("Hello, welcome to Python!")

# Calling the function
greet()
