# Function with return
def add(a, b):
    return a + b

result = add(5, 3)
print("Sum:", result)
