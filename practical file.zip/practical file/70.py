# Function returning a list
def get_numbers():
    return [1, 2, 3, 4, 5]

numbers = get_numbers()
print("List:", numbers)

# Function returning a dictionary
def get_person():
    return {"name": "Alice", "age": 25, "city": "New York"}

person = get_person()
print("Dictionary:", person)

