def greet(name):
    """
    This function greets the person passed in as the parameter.
    """
    print("Hello, " + name + "!")

print(greet.__doc__)
greet("Alice")
