import q82
result=q82.add(10,20)
print(result)

