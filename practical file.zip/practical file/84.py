from math import sqrt

print(sqrt(16))  # Output: 4.0
