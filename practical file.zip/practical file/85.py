from math import *

print(sin(0))  # Output: 0.0
print(factorial(5))  # Output: 120
