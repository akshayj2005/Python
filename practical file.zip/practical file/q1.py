print("this is my first python code")
print("HELLO WORLD")

