# Input data from user
name = input("Enter your name: ")
student_class = input("Enter your class: ")
roll_no = input("Enter your roll number: ")
age = input("Enter your age: ")

# Print using formatted string
print(f"\n--- Student Details ---")
print(f"Name       : {name}")
print(f"Roll No    : {roll_no}")
print(f"Class      : {student_class}")
print(f"Age        : {age}")
print("\n--- End of Details ---")