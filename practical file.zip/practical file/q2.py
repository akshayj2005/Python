#valid identifiers
variable = 10
print(variable)
_variable = "underscore"
print(_variable)
var123 = 3.14
print(var123)

#invalid identifiers
#1variable = 10
#var@123 = 3.14
