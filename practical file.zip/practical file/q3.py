#Using keywords in python

#if-else conditional statement
variable = 7

if variable > 5:
    print("variable is greater than 5")
else:
    print("variable is 5 or less")

#while loop
count = 0

while count < 5:
    print(count)
    count+=1

#for loop
for i in range(5):
    print(i)

#function definition
def my_function():
    print("Hello World")

#Class Definition
class MyClass:
    def _init_(self,value):
        self.value=value


