#proper indentation in a function

def my_function():
    print("this is properly indented")
    if True:
        print("this is inside an if statement")
#properly indented function

def my_other_function():
    print("this will not cause an error") #properly indented

#indentation in a loop

for i in range(5):
    print(i) #properly indented inside the loop

#call the function to see the output

my_function()
my_other_function()
