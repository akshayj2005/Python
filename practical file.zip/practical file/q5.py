# This is a single-line comment
# It is used to explain code briefly on one line

print("Hello, world!")  # This is an inline comment

"""
You can use triple single quotes (''') or 
triple double quotes ("""""") for multi-line comments.
"""


'''
Another way to write multi-line comments.
This is useful for longer explanations or documentation.'''

# End of the example
