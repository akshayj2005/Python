name = input("enter your name ")
print("hello " + name)
