#integer
num=10
print(type(num))

#float
pi=3.14
print(type(pi))

#string
greeting="hello world"
print(type(greeting))

#list
numbers=[1,2,3,4]
print(type(numbers))

#tuple
coordinates=(10.0,20.0)
print(type(coordinates))

#dictionary
person={"name":"alice", "age": 25}
print(type(person))

#set
unique_numbers={1,2,3,3,4}
print(type(unique_numbers))

#bool
is_valid = True
print(type(is_valid))
